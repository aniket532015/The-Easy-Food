# FoodDeliveryApp
A food delivery app with minimal features.It's uses different api for different task.

Includes:
  1. Login and Sign up using api.
  2. Showing all the restaurant and restaurant items using api.
  3. Placing order.
  4. Adding Favourite restaurants.
  5. Some more fuctionality like sort restaurants,profile,logout etc.
  
![combind_first_image](https://user-images.githubusercontent.com/38569124/101740902-6de12b00-3aef-11eb-9e07-778ba87683e0.png)
![combind_second_image](https://user-images.githubusercontent.com/38569124/101741057-9b2dd900-3aef-11eb-96cd-15f7b5d83f6e.png)
![combind_third_image](https://user-images.githubusercontent.com/38569124/101741111-abde4f00-3aef-11eb-91c5-59334d2794f6.png)

