package com.basics.fooddeliveryapp.model

data class FrequentQuestion(
    var question: String,
    var answer: String
)