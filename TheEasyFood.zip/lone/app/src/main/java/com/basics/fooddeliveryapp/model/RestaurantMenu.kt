package com.basics.fooddeliveryapp.model

data class RestaurantMenu(
    var menuId: String,
    var name: String,
    var costForOne: String,
    var restaurantId: String
)